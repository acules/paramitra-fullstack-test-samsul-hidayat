<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Newsmodels;
use Illuminate\Support\Str;
use Carbon\Carbon;

class NewsController extends Controller
{
    public function __construct()
    {
        
    }

    public function index()
    {
        $Datas = Newsmodels::OrderBy('id', 'DESC')->paginate(25);
        if(!empty($Datas)){
          return response()->json(['code' => '200', 'data'=>$Datas, 'status'=>true]);
        }else{
            return response()->json(['code' => '404','data'=> 'Data Not Found', 'status'=>false]);
        }
    }

    public function create(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
        ]);

        $title = trim($request->input("title"));
        $slug = Str::slug($title, '-');
        $desc = $request->input("description");

        $filaname = null;
        if ($request->hasFile('thumbnail')) {
            // GENERATE NAMA UNTUK FILE TERSEBUT DENGAN FORMAT SLUG TITLE
            $file = $request->file('thumbnail');
            $fileName = $slug.'.'.$file->getClientOriginalExtension();
            $file->move(base_path().'/public/images', $fileName);
        }

        $count = Newsmodels::where('newsLink', $slug)->count();
        if($count>0){
            // JIKA DATA SUDAH ADA TIDAK BISA TERSIMPAN
            return response()->json(['code' => '204','message'=> 'data already exists', 'status'=>false]);
        }else{
            $data = [
                'newsLink' => $slug,
                'newsTitle' => Str::title($title),
                'newsDesc' => $desc,
                'newsImages' => $filaname
            ];
            $Datas = Newsmodels::create($data);
            return response()->json(['code' => '201', 'message'=>'success', 'status'=>true]);
        }
    }

    public function show($id)
    {
        $Datas = Newsmodels::find($id);
        if(!empty($Datas)){
          return response()->json(['code' => '200', 'data'=>$Datas, 'status'=>true]);
        }else{
            return response()->json(['code' => '404', 'message'=> 'Data Not Found', 'status'=>false]);
        }
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
        ]);

        $title = trim($request->input("title"));
        $slug = Str::slug($title, '-');
        $desc = $request->input("description");
        $status = $request->input("status");        

        $data = [
                'newsLink' => $slug,
                'newsTitle' => Str::title($title),
                'newsDesc' => $desc,
                'newsActive' => $status
            ];
        $Datas = Newsmodels::whereId($id)->update($data);
        if(!empty($Datas)){
          return response()->json(['code' => '201', 'message'=>'Update Success', 'status'=>true]);
        }else{
            return response()->json(['code' => '400', 'message'=> 'Update Failed', 'status'=>false]);
        }
    }

    public function destroy($id)
    {
        $Datas = Newsmodels::find($id);
        
        if (!$Datas) {
            return response()->json(['code' => '404', 'message'=> 'Data Not Found', 'status'=>false]);
        }
        $Datas->delete();
        return response()->json(['code' => '200', 'message'=>'Deleted successfully', 'status'=>true]);
    }

    public function search(Request $request)
    {
        $this->validate($request, [
            'keyword' => 'required',
        ]);

        $key = trim($request->input('keyword'));

        $Datas = Newsmodels::where('newsTitle', 'like', "%" . $key . "%")
                            ->orWhere('newsDesc', 'like', "%" . $key . "%")
                            ->orWhere('newsDate', 'like', "%" . $key . "%")
                            ->paginate(10);
        $wordCount = count($Datas);
        if($wordCount>0){
            return response()->json(['code' => '200', 'data'=>$Datas, 'status'=>true]);
        }else{
            return response()->json(['code' => '404','data'=> 'Data Not Found', 'status'=>false]);
        }
    }

}
