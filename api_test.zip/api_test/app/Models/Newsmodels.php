<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Support\Facades\DB;

class Newsmodels extends Model
{
    use HasFactory;
    protected $table      = 'tbnews';
    protected $primaryKey = 'id';
    public $timestamps    = true;
    protected $guarded    = ['id'];
    
} 
