<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->get('/', function () use ($router) {
    // return $router->app->version();
    return 'Welcome to API PT PARAMITRA ALPHA SEKURITAS';
});

$router->get('/posts','NewsController@index');
$router->post('/posts','NewsController@create');
$router->get('/posts/{id}','NewsController@show');
$router->put('/posts/{id}','NewsController@update');
$router->delete('/posts/{id}','NewsController@destroy');
$router->post('/posts/search','NewsController@search');